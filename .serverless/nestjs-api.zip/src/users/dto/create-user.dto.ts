export class CreateUserDto {
    firtName:string;
    lastName:string;
    isActive:boolean;
}
